const IMAGES = {
  // Home page
  // logo: new URL("./Img/logo.png", import.meta.url).href,
  hero_image_1: new URL("./Img/hero_1.jpg", import.meta.url).href,
  image_1: new URL("./Img/hero_2.jpg", import.meta.url).href,
  image_2: new URL("./Img/hero_3.jpg", import.meta.url).href,
  image_2: new URL("./Img/hero_3.jpg", import.meta.url).href,
  image_3: new URL("./Img/img_1.jpg", import.meta.url).href,
  children_1: new URL("./Img/children_1.jpg", import.meta.url).href,
  children_2: new URL("./Img/children_2.jpg", import.meta.url).href,
  preg_1: new URL("./Img/preg_1.jpg", import.meta.url).href,
  preg_2: new URL("./Img/preg_2.jpg", import.meta.url).href,
  preg_3: new URL("./Img/preg_3.jpg", import.meta.url).href,
};

export default IMAGES;
